#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bitunix Trading Journal - weekly automatic journal builder
===========================================================
What this script does (READ-ONLY, it never places or changes any order):
  1. Connects to Bitunix with YOUR API key/secret, which stay on YOUR PC
     in a local file called ".env" (never sent anywhere by this script).
  2. Downloads your closed futures positions for a time window
     (GET /api/v1/futures/position/get_history_positions)
  3. Downloads your TP/SL history and matches it to positions by positionId
     (GET /api/v1/futures/tpsl/get_history_orders)
     NOTE: position history itself has NO stop-loss field in Bitunix.
     The SL/TP prices only exist in the TPSL history - that is why we
     need both endpoints to calculate the planned RR.
  4. Calculates for every position:
       planned_rr  = |TP - entry| / |entry - SL|
       realized_R  = realized PnL / (|entry - SL| * qty)   (when SL exists)
  5. Writes into the "output" folder:
       raw_positions_*.json / raw_tpsl_*.json   (exact exchange answers)
       journal_all.csv                          (master journal, no duplicates)
       journal_<from>_to_<to>.csv               (this run's positions)
       weekly_data_<from>_to_<to>.json          (send THIS file to Muse)
       weekly_summary_<from>_to_<to>.txt        (quick numbers for you)

Uses ONLY the Python standard library. Nothing to install with pip.

Signing follows the official Bitunix OpenAPI demo exactly:
  digest = SHA256(nonce + timestamp + api-key + sortedQueryParams + body)
  sign   = SHA256(digest + secretKey)
  headers: api-key, nonce, timestamp (ms), sign, Content-Type: application/json
"""

import argparse
import csv
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE_URL = "https://fapi.bitunix.com"
HERE = Path(__file__).resolve().parent
OUTPUT_DIR = HERE / "output"
STATE_FILE = HERE / "state.json"

# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------

def load_env(path: Path) -> dict:
    """Very small .env reader: KEY=VALUE lines, # comments allowed."""
    env = {}
    if not path.exists():
        return env
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        env[key.strip()] = value.strip().strip('"').strip("'")
    return env


def to_float(value):
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


# All journal times are Tehran time, wherever the script runs (his PC,
# a GitHub runner in UTC, ...). Iran stays on UTC+03:30 year-round.
TEHRAN_TZ = timezone(timedelta(hours=3, minutes=30))


def ms_to_local(ms) -> str:
    v = to_float(ms)
    if v is None:
        return ""
    # Bitunix timestamps are milliseconds
    dt = datetime.fromtimestamp(v / 1000.0, tz=TEHRAN_TZ)
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def round_or_none(value, digits=4):
    if value is None:
        return None
    return round(value, digits)


# --------------------------------------------------------------------------
# Bitunix signed GET (official signing algorithm, standard library only)
# --------------------------------------------------------------------------

def sign(api_key: str, secret_key: str, nonce: str, timestamp: str,
         query_params: str = "", body: str = "") -> str:
    digest = hashlib.sha256(
        (nonce + timestamp + api_key + query_params + body).encode("utf-8")
    ).hexdigest()
    return hashlib.sha256((digest + secret_key).encode("utf-8")).hexdigest()


def sorted_query(params: dict) -> str:
    # Official rule: sort keys in ascending ASCII order, join as key+value
    return "".join(f"{k}{params[k]}" for k in sorted(params.keys()))


class BitunixClient:
    def __init__(self, api_key: str, secret_key: str):
        self.api_key = api_key
        self.secret_key = secret_key

    def get(self, path: str, params: dict) -> dict:
        params = {k: str(v) for k, v in params.items() if v is not None}
        nonce = uuid.uuid4().hex  # 32-char random string, as in the official demo
        timestamp = str(int(time.time() * 1000))
        signature = sign(self.api_key, self.secret_key, nonce, timestamp,
                         query_params=sorted_query(params), body="")
        url = BASE_URL + path
        if params:
            url += "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, method="GET", headers={
            "api-key": self.api_key,
            "nonce": nonce,
            "timestamp": timestamp,
            "sign": signature,
            "Content-Type": "application/json",
            "language": "en-US",
        })
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"HTTP {e.code} from Bitunix: {body[:400]}") from e
        if payload.get("code") != 0:
            raise RuntimeError(
                f"Bitunix error code={payload.get('code')} msg={payload.get('msg')}. "
                "Most common causes: wrong key/secret, key has no Read permission, "
                "or the PC clock is wrong (timestamp must be within 60 seconds)."
            )
        return payload.get("data") or {}

    def get_paginated(self, path: str, list_key: str, base_params: dict,
                      limit: int = 100, max_pages: int = 200) -> list:
        """Bitunix paging uses skip + limit and returns a total count."""
        results, skip = [], 0
        for _ in range(max_pages):
            params = dict(base_params, skip=skip, limit=limit)
            data = self.get(path, params)
            page = data.get(list_key) or []
            results.extend(page)
            total = to_float(data.get("total"))
            if not page or len(page) < limit:
                break
            if total is not None and len(results) >= total:
                break
            skip += limit
            time.sleep(0.25)  # be gentle with the API
        return results


# --------------------------------------------------------------------------
# journal logic
# --------------------------------------------------------------------------

def normalize_side(raw) -> str:
    s = str(raw or "").strip().upper()
    if s in ("LONG", "BUY", "1", "OPEN_LONG"):
        return "LONG"
    if s in ("SHORT", "SELL", "-1", "2", "OPEN_SHORT"):
        return "SHORT"
    return s or "UNKNOWN"


def pick_tpsl(records: list):
    """Bitunix stores SL and TP in SEPARATE TPSL history records:
    one record may carry only slPrice, another only tpPrice.
    So pick per-field: earliest/latest record that carries SL, and
    earliest/latest record that carries TP.
    Returns (sl_first, sl_last, tp_first, tp_last) as prices or None."""
    def series(field):
        vals = [(to_float(r.get("ctime")) or 0, to_float(r.get(field)))
                for r in records if to_float(r.get(field))]
        if not vals:
            return None, None
        vals.sort()
        return vals[0][1], vals[-1][1]

    sl_first, sl_last = series("slPrice")
    tp_first, tp_last = series("tpPrice")
    return sl_first, sl_last, tp_first, tp_last


def count_distinct(records: list, field: str) -> int:
    return len({str(r.get(field)) for r in records
                if to_float(r.get(field)) is not None})


def find_field(pos: dict, *names):
    """Case-insensitive field lookup; Bitunix key names vary by version."""
    lowered = {str(k).lower(): v for k, v in pos.items()}
    for name in names:
        v = lowered.get(name.lower())
        if v is not None and v != "":
            return v
    return None


def build_journal_row(pos: dict, tpsl_records: list) -> dict:
    side = normalize_side(pos.get("side"))
    # History positions call it entryPrice; OPEN (pending) positions
    # call the same value avgOpenPrice - accept both.
    entry = to_float(find_field(pos, "entryPrice", "avgOpenPrice"))
    close = to_float(pos.get("closePrice"))
    qty = to_float(pos.get("maxQty")) or to_float(pos.get("qty"))
    realized = to_float(pos.get("realizedPNL"))
    fee = to_float(pos.get("fee"))
    funding = to_float(pos.get("funding"))

    sl, sl_last, tp, tp_last = pick_tpsl(tpsl_records)

    # If the earliest recorded stop sits (almost) exactly on the entry,
    # it is a moved-to-breakeven stop, not the original plan. Any R
    # computed from it is meaningless (it produced values like -87R),
    # so mark the trade and leave R / RR empty for it.
    sl_at_entry = (
        entry is not None and sl is not None and entry != 0
        and abs(entry - sl) / abs(entry) < 0.0005
    )

    planned_rr = None
    risk_per_unit = None
    risk_usdt = None
    realized_r = None
    if entry is not None and sl is not None and sl != entry and not sl_at_entry:
        risk_per_unit = abs(entry - sl)
        if tp is not None:
            planned_rr = abs(tp - entry) / risk_per_unit
        if qty:
            risk_usdt = risk_per_unit * qty
            if realized is not None and risk_usdt:
                realized_r = realized / risk_usdt
    elif sl_at_entry:
        risk_usdt = None

    ctime, mtime = to_float(pos.get("ctime")), to_float(pos.get("mtime"))
    duration_min = None
    if ctime and mtime and mtime >= ctime:
        duration_min = (mtime - ctime) / 60000.0

    outcome = ""
    if realized is not None:
        outcome = "WIN" if realized > 0 else ("LOSS" if realized < 0 else "BREAKEVEN")

    flags = []
    if sl is None:
        flags.append("NO_SL_RECORDED")
    if tp is None:
        flags.append("NO_TP_RECORDED")
    if sl_at_entry:
        flags.append("SL_AT_ENTRY")
    if (count_distinct(tpsl_records, "slPrice") > 1
            or count_distinct(tpsl_records, "tpPrice") > 1):
        flags.append("TPSL_MODIFIED")
    if realized_r is not None and realized_r < -1.2:
        flags.append("LOSS_BEYOND_1R")
    if (planned_rr and realized_r is not None and outcome == "WIN"
            and realized_r < 0.5 * planned_rr):
        flags.append("CLOSED_EARLY_VS_PLAN")

    return {
        "position_id": str(pos.get("positionId", "")),
        "symbol": pos.get("symbol", ""),
        "side": side,
        "side_raw": str(pos.get("side", "")),
        "open_time": ms_to_local(pos.get("ctime")),
        "close_time": ms_to_local(pos.get("mtime")),
        "duration_minutes": round_or_none(duration_min, 1),
        "entry_price": entry,
        "close_price": close,
        "qty": qty,
        "leverage": pos.get("leverage", ""),
        "margin_mode": str(pos.get("marginMode", "")),
        "margin_usdt": to_float(find_field(
            pos, "margin", "marginAmount", "initialMargin", "openMargin",
            "positionMargin")),
        "sl_price_first": sl,
        "tp_price_first": tp,
        "sl_price_last": sl_last,
        "tp_price_last": tp_last,
        "planned_rr": round_or_none(planned_rr, 3),
        "risk_usdt_planned": round_or_none(risk_usdt, 4),
        "realized_pnl": realized,
        "fee": fee,
        "funding": funding,
        "realized_R": round_or_none(realized_r, 3),
        "liq_price": to_float(pos.get("liqPrice")),
        "outcome": outcome,
        "flags": ";".join(flags),
        "tpsl_records_count": len(tpsl_records),
    }


def summarize(rows: list, window_label: str) -> dict:
    def total(key):
        vals = [r[key] for r in rows if r.get(key) is not None]
        return round(sum(vals), 4) if vals else None

    wins = [r for r in rows if r["outcome"] == "WIN"]
    losses = [r for r in rows if r["outcome"] == "LOSS"]
    with_rr = [r for r in rows if r["planned_rr"] is not None]
    with_r = [r for r in rows if r["realized_R"] is not None]

    def group(key):
        out = {}
        for r in rows:
            k = str(r.get(key) or "unknown")
            g = out.setdefault(k, {"trades": 0, "pnl": 0.0, "wins": 0})
            g["trades"] += 1
            g["pnl"] += r["realized_pnl"] or 0
            g["wins"] += 1 if r["outcome"] == "WIN" else 0
        for g in out.values():
            g["pnl"] = round(g["pnl"], 4)
        return out

    return {
        "window": window_label,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "trades": len(rows),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate_pct": round_or_none(
            100.0 * len(wins) / len(rows), 1) if rows else None,
        "total_realized_pnl": total("realized_pnl"),
        "total_fees": total("fee"),
        "total_funding": total("funding"),
        "avg_planned_rr": round_or_none(
            sum(r["planned_rr"] for r in with_rr) / len(with_rr), 3) if with_rr else None,
        "trades_with_sl_recorded": len([r for r in rows if r["sl_price_first"] is not None]),
        "trades_without_sl": len([r for r in rows if r["sl_price_first"] is None]),
        "avg_realized_R": round_or_none(
            sum(r["realized_R"] for r in with_r) / len(with_r), 3) if with_r else None,
        "sum_realized_R": round_or_none(
            sum(r["realized_R"] for r in with_r), 3) if with_r else None,
        "by_symbol": group("symbol"),
        "by_side": group("side"),
        "flag_counts": {
            flag: sum(1 for r in rows if flag in r["flags"].split(";"))
            for flag in ("NO_SL_RECORDED", "NO_TP_RECORDED", "TPSL_MODIFIED",
                         "LOSS_BEYOND_1R", "CLOSED_EARLY_VS_PLAN", "SL_AT_ENTRY")
        },
    }


JOURNAL_COLUMNS = [
    "position_id", "symbol", "side", "side_raw", "open_time", "close_time",
    "duration_minutes", "entry_price", "close_price", "qty", "leverage",
    "margin_mode", "margin_usdt", "sl_price_first", "tp_price_first",
    "sl_price_last", "tp_price_last", "planned_rr", "risk_usdt_planned",
    "realized_pnl", "fee", "funding", "realized_R", "liq_price", "outcome",
    "flags", "tpsl_records_count",
]


def write_csv(path: Path, rows: list):
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=JOURNAL_COLUMNS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in JOURNAL_COLUMNS})


def update_master_journal(new_rows: list) -> list:
    """Merge new rows into journal_all.csv, deduplicated by position_id."""
    master_path = OUTPUT_DIR / "journal_all.csv"
    merged = {}
    if master_path.exists():
        with master_path.open(encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                if row.get("position_id"):
                    merged[row["position_id"]] = row
    for r in new_rows:
        merged[str(r["position_id"])] = {k: ("" if r.get(k) is None else r.get(k))
                                         for k in JOURNAL_COLUMNS}
    all_rows = sorted(merged.values(), key=lambda r: str(r.get("open_time", "")))
    write_csv(master_path, all_rows)
    return all_rows


# --------------------------------------------------------------------------
# fetching, report text, Telegram (v3 - GitHub Actions ready)
# --------------------------------------------------------------------------

def get_config() -> dict:
    """Environment variables (GitHub Secrets) win over the local .env file."""
    cfg = load_env(HERE / ".env")
    for key in ("BITUNIX_API_KEY", "BITUNIX_API_SECRET",
                "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID",
                "NOTION_TOKEN", "NOTION_DATABASE_ID", "NOTION_SYNC_FROM",
                "ACCOUNT_SIZE_USD"):
        if os.environ.get(key):
            cfg[key] = os.environ[key]
    return cfg


def fetch_window(client: "BitunixClient", start_ms: int, end_ms: int):
    """Download positions + TPSL records for one time window."""
    positions = client.get_paginated(
        "/api/v1/futures/position/get_history_positions", "positionList",
        {"startTime": start_ms, "endTime": end_ms})
    tpsl_all = client.get_paginated(
        "/api/v1/futures/tpsl/get_history_orders", "orderList",
        {"startTime": start_ms, "endTime": end_ms})
    known_ids = {str(t.get("positionId")) for t in tpsl_all}
    for pos in positions:
        pid = str(pos.get("positionId"))
        if pid and pid not in known_ids:
            tpsl_all.extend(client.get_paginated(
                "/api/v1/futures/tpsl/get_history_orders", "orderList",
                {"positionId": pid}))
            time.sleep(0.25)
    return positions, tpsl_all


def rows_from(positions: list, tpsl_all: list) -> list:
    by_position = {}
    for t in tpsl_all:
        by_position.setdefault(str(t.get("positionId")), []).append(t)
    rows = [build_journal_row(p, by_position.get(str(p.get("positionId")), []))
            for p in positions]
    rows.sort(key=lambda r: r["open_time"])
    return rows


def max_losing_streak(rows: list) -> int:
    best = run = 0
    for r in sorted(rows, key=lambda x: x["close_time"]):
        run = run + 1 if r["outcome"] == "LOSS" else 0
        best = max(best, run)
    return best


def build_report_text(rows: list, stats: dict, prev_stats: dict = None) -> str:
    """Persian weekly report, generated locally from the numbers only."""
    label = stats["window"].replace("_to_", " تا ")
    lines = [
        "📊 گزارش هفتگی معاملات Bitunix",
        f"بازه: {label}",
        "",
        f"معاملات: {stats['trades']} | برد: {stats['wins']} | باخت: {stats['losses']} "
        f"| نرخ برد: {stats['win_rate_pct']}٪",
        f"سود/زیان خالص: {stats['total_realized_pnl']} USDT",
        f"کارمزد: {stats['total_fees']} | فاندینگ: {stats['total_funding']}",
        f"میانگین RR برنامه: {stats['avg_planned_rr']} | "
        f"میانگین R تحقق‌یافته: {stats['avg_realized_R']} | مجموع R: {stats['sum_realized_R']}",
        f"طولانی‌ترین روند باخت: {max_losing_streak(rows)} معامله",
        f"معاملات بدون استاپ ثبت‌شده: {stats['trades_without_sl']} از {stats['trades']}",
    ]
    if prev_stats:
        lines += [
            "",
            "مقایسه با هفته قبل:",
            f"هفته قبل: {prev_stats['trades']} معامله، نرخ برد {prev_stats['win_rate_pct']}٪، "
            f"سود/زیان {prev_stats['total_realized_pnl']} USDT",
        ]
    # symbols: worst and best (needs at least 2 trades to be a "pattern")
    sym = sorted((v["pnl"], k, v["trades"], v["wins"])
                 for k, v in stats["by_symbol"].items())
    if sym:
        lines += ["", "نمادها (بدترین‌ها):"]
        for pnl, name, n, w in sym[:3]:
            lines.append(f"{name}: ‏{n} معامله، {w} برد، {pnl} USDT")
        best = sym[-1]
        lines.append(f"بهترین: {best[1]}: ‏{best[2]} معامله، {best[3]} برد، {best[0]} USDT")
    lng = stats["by_side"].get("LONG")
    sht = stats["by_side"].get("SHORT")
    side_bits = []
    if lng:
        side_bits.append(f"لانگ: {lng['trades']} معامله، {lng['wins']} برد، {lng['pnl']} USDT")
    if sht:
        side_bits.append(f"شورت: {sht['trades']} معامله، {sht['wins']} برد، {sht['pnl']} USDT")
    if side_bits:
        lines += ["", " | ".join(side_bits)]
    # open-hour clusters with >=3 trades (the pattern found in Oct 2026 data)
    hours = {}
    for r in rows:
        try:
            h = int(r["open_time"][11:13])
        except (ValueError, IndexError):
            continue
        g = hours.setdefault(h, {"n": 0, "pnl": 0.0, "wins": 0})
        g["n"] += 1
        g["pnl"] += r["realized_pnl"] or 0
        g["wins"] += 1 if r["outcome"] == "WIN" else 0
    bad_hours = sorted(
        ((round(v["pnl"], 2), h, v) for h, v in hours.items() if v["n"] >= 3),
        key=lambda x: x[0])
    if bad_hours and bad_hours[0][0] < 0:
        lines += ["", "خوشه‌های ساعتی (ورود):"]
        for pnl, h, v in bad_hours[:2]:
            lines.append(
                f"ساعت {h:02d}: ‏{v['n']} معامله، {v['wins']} برد، {pnl} USDT")
    if rows:
        worst = min(rows, key=lambda r: r["realized_pnl"] or 0)
        best_t = max(rows, key=lambda r: r["realized_pnl"] or 0)
        lines += [
            "",
            f"بدترین معامله: {worst['symbol']} {worst['side']} "
            f"{round(worst['realized_pnl'] or 0, 2)} USDT ({worst['close_time'][:10]})",
            f"بهترین معامله: {best_t['symbol']} {best_t['side']} "
            f"+{round(best_t['realized_pnl'] or 0, 2)} USDT ({best_t['close_time'][:10]})",
        ]
    fc = stats["flag_counts"]
    active_flags = {k: v for k, v in fc.items() if v}
    if active_flags:
        lines += ["", f"پرچم‌ها: {json.dumps(active_flags, ensure_ascii=False)}"]
    insights = build_insights(rows, stats, prev_stats)
    if insights:
        lines += ["", "📌 نکات، اشتباه‌ها و پیشنهادها:"]
        lines += [f"{i + 1}. {s}" for i, s in enumerate(insights)]
    lines += ["", "فایل کامل ژورنال پیوست شده است."]
    return "\n".join(lines)


def build_insights(rows: list, stats: dict, prev_stats: dict = None) -> list:
    """Rule-based coaching notes (v4): mistakes, warnings and tips computed
    from the numbers only - deterministic, no guessing."""
    out = []
    trades = stats["trades"]
    if trades == 0:
        return out
    wins = [r for r in rows if r["outcome"] == "WIN"]
    losses = [r for r in rows if r["outcome"] == "LOSS"]
    net = stats["total_realized_pnl"]

    # 1) breakeven math: is the win rate enough for this payoff ratio?
    if wins and losses:
        avg_win = sum(r["realized_pnl"] for r in wins) / len(wins)
        avg_loss = abs(sum(r["realized_pnl"] for r in losses) / len(losses))
        if avg_loss > 0:
            payoff = avg_win / avg_loss
            be = 100.0 / (1.0 + payoff)
            if stats["win_rate_pct"] < be:
                out.append(
                    f"⚠️ نرخ برد {stats['win_rate_pct']}٪ کمتر از نقطه سربه‌سر توست. "
                    f"با میانگین سود {round(avg_win, 2)} و زیان {round(avg_loss, 2)} USDT "
                    f"(نسبت {round(payoff, 2)}) باید حداقل {round(be, 1)}٪ ببری تا ضرر نکنی. "
                    "یا ورودی‌ها را گزیده‌تر کن یا RR هدف را بالاتر ببر.")

    # 2) worst 2-hour entry window
    hours = {}
    for r in rows:
        try:
            h = int(r["open_time"][11:13])
        except (ValueError, IndexError):
            continue
        g = hours.setdefault(h, [0, 0.0, 0])
        g[0] += 1
        g[1] += r["realized_pnl"] or 0
        g[2] += 1 if r["outcome"] == "WIN" else 0
    windows = []
    for h in range(24):
        n = pnl = wn = 0
        for hh in (h, (h + 1) % 24):
            if hh in hours:
                n += hours[hh][0]
                pnl += hours[hh][1]
                wn += hours[hh][2]
        if n >= 4:
            windows.append((pnl, h, n, wn))
    windows.sort()
    if windows and windows[0][0] < 0:
        pnl, h, n, wn = windows[0]
        share = (f" ({round(100 * pnl / net)}٪ از زیان خالص دوره)"
                 if net < 0 and pnl < 0 else "")
        out.append(
            f"🕑 بدترین بازه ورود: ساعت {h:02d} تا {h + 2:02d} — ‏{n} معامله، "
            f"{wn} برد، {round(pnl, 2)} USDT{share}. "
            "پیشنهاد: این هفته در این بازه ورود جدید نزن یا حجم را نصف کن.")
    if windows and windows[-1][0] > 0 and windows[-1][0] != windows[0][0]:
        pnl, h, n, wn = windows[-1]
        out.append(
            f"✅ بهترین بازه ورود: ساعت {h:02d} تا {h + 2:02d} — ‏{n} معامله، "
            f"{wn} برد، +{round(pnl, 2)} USDT. این ساعت‌ها تمرکزت بهتر است.")

    # 3) worst symbol concentration
    worst = None
    for name, v in stats["by_symbol"].items():
        if worst is None or v["pnl"] < worst[1]["pnl"]:
            worst = (name, v)
    if worst and worst[1]["pnl"] < 0 and worst[1]["trades"] >= 3 and net < 0:
        share = round(100 * worst[1]["pnl"] / net)
        if share >= 25:
            out.append(
                f"🎯 نماد {worst[0]} به‌تنهایی {share}٪ از زیان خالص را ساخته "
                f"({worst[1]['trades']} معامله، {worst[1]['wins']} برد، "
                f"{round(worst[1]['pnl'], 2)} USDT). پیشنهاد: یک هفته از این نماد استراحت کن "
                "یا حجمش را نصف کن.")

    # 4) one-sided bias
    for side, fa in (("LONG", "لانگ"), ("SHORT", "شورت")):
        v = stats["by_side"].get(side)
        if v and trades >= 8 and v["trades"] >= 0.75 * trades and v["pnl"] < 0:
            out.append(
                f"↔️ سوگیری یک‌طرفه: {round(100 * v['trades'] / trades)}٪ معاملاتت "
                f"{fa} بوده و نتیجه‌اش {round(v['pnl'], 2)} USDT شده. قبل از هر ورود، "
                "سناریوی مخالف را هم بررسی کن.")

    # 5) losing streak / tilt
    streak = max_losing_streak(rows)
    if streak >= 5:
        out.append(
            f"🔥 طولانی‌ترین روند باخت: {streak} معامله پشت سر هم. "
            "قانون پیشنهادی: بعد از ۳ باخت متوالی، ترید آن روز را متوقف کن.")

    # 6) overtrading
    if trades >= 14:
        extra = (f" هفته قبل {prev_stats['trades']} معامله داشتی."
                 if prev_stats else "")
        out.append(
            f"📈 حجم معاملات بالا: {trades} معامله در این بازه.{extra} "
            "تعداد کمتر و گزیده‌تر معمولا کیفیت ورود را بالا می‌برد؛ "
            "سقف آزمایشی: هفته‌ای ۷ تا ۱۰ معامله.")

    # 7) trades without a recorded stop
    if stats["trades_without_sl"] > 0:
        out.append(
            f"🛑 {stats['trades_without_sl']} معامله بدون استاپ ثبت‌شده. "
            "ورود بدون SL یعنی ریسک نامحدود؛ هیچ ورودی بدون استاپ نزن.")

    # 8) losses beyond 1R
    beyond = stats["flag_counts"].get("LOSS_BEYOND_1R", 0)
    if beyond >= 2:
        out.append(
            f"📉 در {beyond} معامله زیان از ۱R گذشته است؛ یعنی استاپ یا "
            "جابه‌جا شده یا اسلیپیج خورده‌ای. این‌ها را در ژورنال علامت بزن.")

    # 9) near-liquidation risk
    liq = stats["flag_counts"].get("RISK_NEAR_LIQ", 0)
    if liq > 0:
        out.append(
            f"☠️ در {liq} معامله فاصله استاپ به فاصله لیکویید شدن نزدیک بوده "
            "(لوریج بالا + استاپ دور). با لوریج بالا، استاپ باید خیلی نزدیک‌تر باشد.")

    # 10) fee drag
    gross_profit = sum(r["realized_pnl"] for r in wins)
    if gross_profit > 0 and stats["total_fees"] >= 0.15 * gross_profit:
        out.append(
            f"💸 کارمزدها {round(100 * stats['total_fees'] / gross_profit)}٪ از "
            "سود ناخالصت را خورده‌اند؛ نشانه استاپ‌های خیلی نزدیک یا حجم نامتناسب "
            "با سایز پوزیشن است. ریسک دلاری هر معامله را حداقل ۵ برابر کارمزد رفت‌وبرگشت نگه دار.")

    # 11) winners closed earlier than planned
    w_rr = [r for r in wins
            if r.get("realized_R") is not None and r.get("planned_rr")]
    if len(w_rr) >= 3:
        avg_r = sum(r["realized_R"] for r in w_rr) / len(w_rr)
        avg_plan = sum(r["planned_rr"] for r in w_rr) / len(w_rr)
        if avg_plan > 0 and avg_r < 0.7 * avg_plan:
            out.append(
                f"✂️ سودها زود بسته می‌شوند: میانگین R بردهایت {round(avg_r, 2)} "
                f"است ولی برنامه‌ات {round(avg_plan, 2)}R بود. بخشی از سود را "
                "زود بردار ولی اجازه بده بقیه تا تارگت بدود.")

    # 12) too many different symbols
    uniq = len(stats["by_symbol"])
    if trades >= 10 and uniq >= 0.6 * trades:
        out.append(
            f"🎲 پراکندگی نمادها بالا: {uniq} نماد متفاوت در {trades} معامله. "
            "روی چند نماد محدود تمرکز کن تا رفتارشان را بشناسی.")

    # 13) week-over-week note
    if prev_stats and prev_stats["trades"]:
        d = round(net - prev_stats["total_realized_pnl"], 2)
        if d > 0:
            out.append(
                f"📊 نسبت به هفته قبل +{d} USDT بهتر شده‌ای "
                f"(هفته قبل: {prev_stats['total_realized_pnl']} USDT).")
        elif d < 0:
            out.append(
                f"📊 نسبت به هفته قبل {d} USDT بدتر شده‌ای "
                f"(هفته قبل: {prev_stats['total_realized_pnl']} USDT). "
                "ببین این هفته چه چیزی عوض شده بود.")
    return out


# --------------------------------------------------------------------------
# Notion writer (v5): append trades to Arshia's manual journal database,
# in his own column style (verified against his LOG2026 entries).
# --------------------------------------------------------------------------

NOTION_API = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"


def _fmt_price(x) -> str:
    if x is None:
        return ""
    s = f"{float(x):.10f}".rstrip("0").rstrip(".")
    return s or "0"


def _fmt_num(x, digits: int = 2) -> str:
    if x is None:
        return ""
    s = f"{round(float(x), digits):.{digits}f}".rstrip("0").rstrip(".")
    return s or "0"


def _rich(text: str) -> dict:
    return {"rich_text": [{"text": {"content": text}}] if text else []}


def notion_request(token: str, method: str, path: str, body: dict = None) -> dict:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        NOTION_API + path, data=data, method=method,
        headers={"Authorization": f"Bearer {token}",
                 "Notion-Version": NOTION_VERSION,
                 "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:300]
        raise RuntimeError(f"Notion API {method} {path} -> HTTP {e.code}: {detail}")


def build_notion_properties(row: dict, nu: int, schema: dict,
                            symbol_names: dict, leverage_names: dict,
                            account_size: float) -> dict:
    """Map one journal row to Notion properties in Arshia's style."""
    props = {}
    title_prop = next((k for k, v in schema.items()
                       if v.get("type") == "title"), "Nu.")
    props[title_prop] = {"title": [{"text": {"content": str(nu)}}]}
    base_symbol = row["symbol"].replace("USDT", "").replace("PERP", "")
    if "Symbol" in schema:
        props["Symbol"] = {"select": {
            "name": symbol_names.get(base_symbol.lower(), base_symbol)}}
    if "Direction" in schema:
        props["Direction"] = {"multi_select": [{"name": row["side"]}]}
    if "Date" in schema:
        props["Date"] = {"date": {"start": row["open_time"][:10]}}
    if "Time" in schema:
        props["Time"] = _rich(row["open_time"][11:16])
    if "Entry Price" in schema:
        props["Entry Price"] = _rich(_fmt_price(row["entry_price"]))
    if "Leverage" in schema:
        try:
            lev = f"{int(float(row['leverage']))}X"
        except (TypeError, ValueError):
            lev = str(row["leverage"])
        props["Leverage"] = {"select": {
            "name": leverage_names.get(lev.lower(), lev)}}
    if "Volume" in schema:
        notional = (row["qty"] or 0) * (row["entry_price"] or 0)
        props["Volume"] = _rich(f"{round(notional)}$" if notional else "")
    if "SL" in schema and row.get("sl_price_first") and row["entry_price"]:
        sl_pct = abs(row["entry_price"] - row["sl_price_first"]) \
            / row["entry_price"] * 100
        props["SL"] = _rich(f"{_fmt_num(sl_pct)}%")
    if "RR" in schema and row.get("planned_rr"):
        props["RR"] = _rich(f"RR{_fmt_num(row['planned_rr'])}")
    if "Risk" in schema and row.get("risk_usdt_planned") is not None \
            and account_size > 0:
        risk_pct = row["risk_usdt_planned"] / account_size * 100
        props["Risk"] = _rich(f"{_fmt_num(risk_pct, 3)}%")
    if "P/L" in schema:
        pl = {"WIN": "Profit", "LOSS": "Loss"}.get(row["outcome"])
        if pl is None and (row["realized_pnl"] or 0) == 0:
            pl = "Risk Free"
        if pl:
            props["P/L"] = {"select": {"name": pl}}
    return props


def notion_sync(rows: list, cfg: dict) -> None:
    """Append new trades to the Notion journal. Never raises: a Notion
    problem must not block the Telegram report."""
    token = cfg.get("NOTION_TOKEN", "")
    db_id = cfg.get("NOTION_DATABASE_ID", "")
    if not token or not db_id or "PASTE" in token:
        print("Notion: skipped (NOTION_TOKEN / NOTION_DATABASE_ID not set).")
        return
    try:
        account_size = float(cfg.get("ACCOUNT_SIZE_USD", "800") or 800)
    except ValueError:
        account_size = 800.0
    sync_from = cfg.get("NOTION_SYNC_FROM", "")
    try:
        db = notion_request(token, "GET", f"/databases/{db_id}")
        schema = db.get("properties", {})
        if not schema:
            print("Notion: database schema is empty - is the database "
                  "shared with the integration?")
            return

        def option_map(prop: str) -> dict:
            p = schema.get(prop, {})
            opts = (p.get(p.get("type", ""), {}) or {}).get("options", [])
            return {o["name"].lower(): o["name"] for o in opts}

        symbol_names = option_map("Symbol")
        leverage_names = option_map("Leverage")

        # read existing rows: next Nu. + dedup keys (date, symbol, entry)
        existing = []
        cursor = None
        while True:
            body = {"page_size": 100}
            if cursor:
                body["start_cursor"] = cursor
            res = notion_request(token, "POST",
                                 f"/databases/{db_id}/query", body)
            existing.extend(res.get("results", []))
            if not res.get("has_more"):
                break
            cursor = res.get("next_cursor")

        def plain(prop_val: dict) -> str:
            t = prop_val.get("type", "")
            v = prop_val.get(t)
            if t in ("title", "rich_text"):
                return "".join(x.get("plain_text", "") for x in (v or []))
            if t == "select":
                return (v or {}).get("name", "")
            return ""

        max_nu = 0
        seen = []
        for page in existing:
            p = page.get("properties", {})
            try:
                max_nu = max(max_nu, int(plain(p.get("Nu.", {}))))
            except ValueError:
                pass
            d = (p.get("Date", {}).get("date") or {}).get("start", "")[:10]
            s = plain(p.get("Symbol", {})).upper()
            try:
                e = float(plain(p.get("Entry Price", {})))
            except ValueError:
                e = None
            if d and s:
                seen.append((d, s, e))

        added = skipped = 0
        nu = max_nu
        for row in sorted(rows, key=lambda r: r["open_time"]):
            if sync_from and row["open_time"][:10] < sync_from:
                continue
            base = row["symbol"].replace("USDT", "").replace("PERP", "")
            dup = any(d == row["open_time"][:10] and s == base.upper()
                      and (e is None or row["entry_price"] is None
                           or abs(e - row["entry_price"])
                           <= 0.01 * max(e, row["entry_price"]))
                      for d, s, e in seen)
            if dup:
                skipped += 1
                continue
            nu += 1
            props = build_notion_properties(
                row, nu, schema, symbol_names, leverage_names, account_size)
            notion_request(token, "POST", "/pages",
                           {"parent": {"database_id": db_id},
                            "properties": props})
            seen.append((row["open_time"][:10], base.upper(),
                         row["entry_price"]))
            added += 1
            time.sleep(0.35)
        print(f"Notion: {added} row(s) added, {skipped} already present.")
    except Exception as e:
        print(f"Notion sync failed (Telegram report unaffected): {e}")


# --------------------------------------------------------------------------
# Notion live sync (v6): open positions appear in the journal as "Open"
# within one poll cycle; when a position closes, its row is completed.
# Rule: the machine only fills EMPTY cells - it never overwrites a value
# Arshia typed himself.
# --------------------------------------------------------------------------

def _notion_query_all(token: str, db_id: str) -> list:
    pages, cursor = [], None
    while True:
        body = {"page_size": 100}
        if cursor:
            body["start_cursor"] = cursor
        res = notion_request(token, "POST", f"/databases/{db_id}/query", body)
        pages.extend(res.get("results", []))
        if not res.get("has_more"):
            return pages
        cursor = res.get("next_cursor")


def _notion_plain(prop_val: dict) -> str:
    t = prop_val.get("type", "")
    v = prop_val.get(t)
    if t in ("title", "rich_text"):
        return "".join(x.get("plain_text", "") for x in (v or []))
    if t == "select":
        return (v or {}).get("name", "")
    if t == "multi_select":
        return ",".join(o.get("name", "") for o in (v or []))
    if t == "date":
        return ((v or {}).get("start") or "")[:10]
    return ""


def _row_key(date: str, symbol: str, entry) -> tuple:
    return (date, (symbol or "").upper(), entry)


def _keys_match(a: tuple, b: tuple) -> bool:
    if a[0] != b[0] or a[1] != b[1]:
        return False
    ea, eb = a[2], b[2]
    if ea is None or eb is None:
        return True
    return abs(ea - eb) <= 0.01 * max(ea, eb)


def notion_live_sync(client: "BitunixClient", cfg: dict) -> None:
    token = cfg.get("NOTION_TOKEN", "")
    db_id = cfg.get("NOTION_DATABASE_ID", "")
    if not token or not db_id or "PASTE" in token:
        print("Notion live sync: skipped (token / database id not set).")
        return
    try:
        account_size = float(cfg.get("ACCOUNT_SIZE_USD", "800") or 800)
    except ValueError:
        account_size = 800.0
    sync_from = cfg.get("NOTION_SYNC_FROM", "")

    db = notion_request(token, "GET", f"/databases/{db_id}")
    schema = db.get("properties", {})
    if not schema:
        print("Notion live sync: empty schema - database not shared?")
        return

    def option_map(prop: str) -> dict:
        p = schema.get(prop, {})
        opts = (p.get(p.get("type", ""), {}) or {}).get("options", [])
        return {o["name"].lower(): o["name"] for o in opts}

    symbol_names = option_map("Symbol")
    leverage_names = option_map("Leverage")

    # index current Notion rows
    index = []
    for page in _notion_query_all(token, db_id):
        p = page.get("properties", {})
        texts = {name: _notion_plain(pv) for name, pv in p.items()}
        try:
            entry = float(texts.get("Entry Price", ""))
        except ValueError:
            entry = None
        try:
            nu = int(texts.get("Nu.", ""))
        except ValueError:
            nu = 0
        index.append({
            "page_id": page["id"], "nu": nu, "texts": texts,
            "pl": texts.get("P/L", ""),
            "key": _row_key(texts.get("Date", ""),
                            texts.get("Symbol", "").replace("USDT", "")
                            .replace("PERP", ""), entry),
        })
    next_nu = max((r["nu"] for r in index), default=0) + 1

    def base_of(row):
        return row["symbol"].replace("USDT", "").replace("PERP", "")

    def fill_blanks(notion_row: dict, props: dict) -> dict:
        """Keep only properties whose Notion cell is currently empty
        (plus P/L when the caller forces it via props)."""
        out = {}
        for name, val in props.items():
            if name in ("Nu.",):
                continue
            if notion_row["texts"].get(name, "") == "":
                out[name] = val
        return out

    created = updated = 0

    # ---- 1) open positions -------------------------------------------------
    data = client.get("/api/v1/futures/position/get_pending_positions", {})
    if isinstance(data, dict):
        open_positions = data.get("positionList") or data.get("positions") or []
    elif isinstance(data, list):
        open_positions = data
    else:
        open_positions = []
    pending_tpsl = []
    try:
        tdata = client.get("/api/v1/futures/tpsl/get_pending_orders", {})
        if isinstance(tdata, dict):
            pending_tpsl = tdata.get("orderList") or tdata.get("orders") or []
        elif isinstance(tdata, list):
            pending_tpsl = tdata
    except Exception as e:
        print(f"Notion live sync: pending TPSL unavailable ({e}); "
              "SL/RR will be filled when the position closes.")
    tpsl_by_pos = {}
    for t in pending_tpsl:
        tpsl_by_pos.setdefault(str(t.get("positionId")), []).append(t)

    open_keys = {}
    for pos in open_positions:
        row = build_journal_row(
            pos, tpsl_by_pos.get(str(pos.get("positionId")), []))
        if sync_from and row["open_time"][:10] < sync_from:
            continue
        key = _row_key(row["open_time"][:10], base_of(row), row["entry_price"])
        open_keys[key] = open_keys.get(key, 0) + 1
        candidates = [r for r in index
                      if _keys_match(r["key"], key)
                      and r["pl"] in ("Open", "")]
        if len(candidates) >= open_keys[key]:
            # already journaled: fill any blanks (e.g. SL added later)
            target = candidates[open_keys[key] - 1]
            props = build_notion_properties(
                row, target["nu"], schema, symbol_names, leverage_names,
                account_size)
            props.pop("Nu.", None)
            patch = fill_blanks(target, props)
            if target["pl"] == "" and "P/L" in schema:
                patch["P/L"] = {"select": {"name": "Open"}}
            if patch:
                notion_request(token, "PATCH", f"/pages/{target['page_id']}",
                               {"properties": patch})
                updated += 1
            continue
        props = build_notion_properties(
            row, next_nu, schema, symbol_names, leverage_names, account_size)
        if "P/L" in schema:
            props["P/L"] = {"select": {"name": "Open"}}
        notion_request(token, "POST", "/pages",
                       {"parent": {"database_id": db_id}, "properties": props})
        index.append({"page_id": "new", "nu": next_nu,
                      "texts": {"P/L": "Open"}, "pl": "Open", "key": key})
        next_nu += 1
        created += 1
        time.sleep(0.35)

    # ---- 2) recently closed positions --------------------------------------
    now_ms = int(time.time() * 1000)
    c_pos, c_tpsl = fetch_window(client, now_ms - 3 * 86400 * 1000, now_ms)
    closed_rows = rows_from(c_pos, c_tpsl)
    used_pages = set()
    for row in closed_rows:
        if sync_from and row["open_time"][:10] < sync_from:
            continue
        key = _row_key(row["open_time"][:10], base_of(row), row["entry_price"])
        open_match = next(
            (r for r in index
             if _keys_match(r["key"], key) and r["pl"] in ("Open", "")
             and r["page_id"] not in used_pages), None)
        if open_match is not None:
            used_pages.add(open_match["page_id"])
            props = build_notion_properties(
                row, open_match["nu"], schema, symbol_names,
                leverage_names, account_size)
            props.pop("Nu.", None)
            patch = fill_blanks(open_match, props)
            if "P/L" in props:  # outcome is final now: always set it
                patch["P/L"] = props["P/L"]
            if patch:
                notion_request(token, "PATCH",
                               f"/pages/{open_match['page_id']}",
                               {"properties": patch})
                updated += 1
            continue
        final_exists = any(_keys_match(r["key"], key)
                           and r["pl"] in ("Profit", "Loss", "Risk Free")
                           for r in index)
        if final_exists:
            continue
        props = build_notion_properties(
            row, next_nu, schema, symbol_names, leverage_names, account_size)
        notion_request(token, "POST", "/pages",
                       {"parent": {"database_id": db_id}, "properties": props})
        index.append({"page_id": "new", "nu": next_nu,
                      "texts": {"P/L": "done"}, "pl": "done", "key": key})
        next_nu += 1
        created += 1
        time.sleep(0.35)

    print(f"Notion live sync: {created} created, {updated} updated, "
          f"{len(open_positions)} open position(s) seen.")


def telegram_send_message(token: str, chat_id: str, text: str) -> None:
    """Telegram sendMessage, split into <4000-char chunks."""
    for i in range(0, len(text), 3900):
        chunk = text[i:i + 3900]
        data = urllib.parse.urlencode(
            {"chat_id": chat_id, "text": chunk}).encode("utf-8")
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{token}/sendMessage", data=data)
        with urllib.request.urlopen(req, timeout=30) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        if not payload.get("ok"):
            raise RuntimeError(f"Telegram sendMessage failed: {payload}")


def telegram_send_document(token: str, chat_id: str, path: Path,
                           caption: str = "") -> None:
    """Telegram sendDocument with a hand-built multipart body (stdlib)."""
    boundary = "----journal" + uuid.uuid4().hex
    file_bytes = path.read_bytes()
    parts = []
    parts.append(f"--{boundary}\r\nContent-Disposition: form-data; "
                 f"name=\"chat_id\"\r\n\r\n{chat_id}\r\n".encode("utf-8"))
    if caption:
        parts.append(f"--{boundary}\r\nContent-Disposition: form-data; "
                     f"name=\"caption\"\r\n\r\n{caption}\r\n".encode("utf-8"))
    parts.append(
        (f"--{boundary}\r\nContent-Disposition: form-data; name=\"document\"; "
         f"filename=\"{path.name}\"\r\nContent-Type: application/octet-stream"
         f"\r\n\r\n").encode("utf-8") + file_bytes + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode("utf-8"))
    body = b"".join(parts)
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/sendDocument", data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    if not payload.get("ok"):
        raise RuntimeError(f"Telegram sendDocument failed: {payload}")


# --------------------------------------------------------------------------
# demo data (used with --demo, no network, no keys needed)
# --------------------------------------------------------------------------

DEMO_POSITIONS = [
    {"positionId": "DEMO1", "symbol": "BTCUSDT", "side": "LONG",
     "entryPrice": "100000", "closePrice": "103600", "maxQty": "0.01",
     "leverage": 10, "marginMode": "ISOLATION", "margin": "100",
     "fee": "1.2", "funding": "0.1", "realizedPNL": "36",
     "liqPrice": "90500", "ctime": 1760000000000, "mtime": 1760007200000},
    {"positionId": "DEMO2", "symbol": "ETHUSDT", "side": "SHORT",
     "entryPrice": "4000", "closePrice": "4120", "maxQty": "0.5",
     "leverage": 5, "marginMode": "ISOLATION", "margin": "400",
     "fee": "0.8", "funding": "0", "realizedPNL": "-60",
     "liqPrice": "4750", "ctime": 1760100000000, "mtime": 1760103600000},
    {"positionId": "DEMO3", "symbol": "SOLUSDT", "side": "LONG",
     "entryPrice": "200", "closePrice": "188", "maxQty": "2",
     "leverage": 5, "marginMode": "ISOLATION", "margin": "80",
     "fee": "0.5", "funding": "0", "realizedPNL": "-24",
     "liqPrice": "165", "ctime": 1760200000000, "mtime": 1760210800000},
    {"positionId": "DEMO4", "symbol": "ADAUSDT", "side": "LONG",
     "entryPrice": "1.00", "closePrice": "1.18", "maxQty": "100",
     "leverage": 10, "marginMode": "ISOLATION", "margin": "10",
     "fee": "0.4", "funding": "0", "realizedPNL": "18",
     "liqPrice": "0.90", "ctime": 1760300000000, "mtime": 1760307200000},
]
DEMO_TPSL = [
    {"id": "T1", "positionId": "DEMO1", "symbol": "BTCUSDT",
     "tpPrice": "104000", "slPrice": "98000", "ctime": 1760000060000},
    {"id": "T2", "positionId": "DEMO3", "symbol": "SOLUSDT",
     "tpPrice": "220", "slPrice": "190", "ctime": 1760200060000},
    # DEMO2 intentionally has no TPSL record -> NO_SL_RECORDED, RR unknown
    # DEMO4 mimics the real Bitunix behaviour found in Arshia's first run:
    # SL and TP arrive as SEPARATE records (one slPrice-only, one tpPrice-only)
    {"id": "T3", "positionId": "DEMO4", "symbol": "ADAUSDT",
     "slPrice": "0.90", "ctime": 1760300060000},
    {"id": "T4", "positionId": "DEMO4", "symbol": "ADAUSDT",
     "tpPrice": "1.20", "ctime": 1760300120000},
]


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------

def resolve_window(args) -> (int, int, str):
    now = datetime.now(TEHRAN_TZ)
    if args.last_full_week:
        # previous Monday 00:00:00 to Sunday 23:59:59 (Tehran time)
        this_monday = (now - timedelta(days=now.weekday())).replace(
            hour=0, minute=0, second=0, microsecond=0)
        start = this_monday - timedelta(days=7)
        end = this_monday - timedelta(seconds=1)
    elif args.start or args.end:
        start = datetime.fromisoformat(args.start) if args.start else now - timedelta(days=args.days)
        end = datetime.fromisoformat(args.end) if args.end else now
        if start.tzinfo is None:
            start = start.replace(tzinfo=TEHRAN_TZ)
        if end.tzinfo is None:
            end = end.replace(tzinfo=TEHRAN_TZ)
    else:
        end = now
        start = now - timedelta(days=args.days)
    label = f"{start.strftime('%Y-%m-%d')}_to_{end.strftime('%Y-%m-%d')}"
    return int(start.timestamp() * 1000), int(end.timestamp() * 1000), label


def main() -> int:
    parser = argparse.ArgumentParser(description="Bitunix weekly trading journal")
    parser.add_argument("--days", type=int, default=7,
                        help="look back this many days (default 7)")
    parser.add_argument("--start", help="start date, e.g. 2026-10-01")
    parser.add_argument("--end", help="end date, e.g. 2026-10-07")
    parser.add_argument("--last-full-week", action="store_true",
                        help="use previous Monday-Sunday (used by the weekly task)")
    parser.add_argument("--demo", action="store_true",
                        help="run with sample data, no keys and no network")
    parser.add_argument("--telegram", action="store_true",
                        help="send the report and journal files to Telegram")
    parser.add_argument("--notion", action="store_true",
                        help="append new trades to the Notion journal")
    parser.add_argument("--sync", action="store_true",
                        help="live Notion sync: journal open positions as "
                             "Open, complete their rows when they close")
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(exist_ok=True)

    if args.sync:
        cfg = get_config()
        api_key = cfg.get("BITUNIX_API_KEY", "")
        secret_key = cfg.get("BITUNIX_API_SECRET", "")
        if not api_key or not secret_key or "PASTE" in api_key:
            print("ERROR: API key/secret not found (env or .env).")
            return 2
        notion_live_sync(BitunixClient(api_key, secret_key), cfg)
        return 0

    start_ms, end_ms, label = resolve_window(args)
    print(f"Window: {label}  (startTime={start_ms}, endTime={end_ms})")

    cfg = get_config()
    prev_stats = None

    if args.demo:
        positions, tpsl_all = DEMO_POSITIONS, DEMO_TPSL
        print("DEMO mode: using built-in sample data.")
    else:
        api_key = cfg.get("BITUNIX_API_KEY", "")
        secret_key = cfg.get("BITUNIX_API_SECRET", "")
        if not api_key or not secret_key or "PASTE" in api_key:
            print("\nERROR: API key/secret not found.")
            print("Local run: put them in the .env file in this folder.")
            print("GitHub Actions run: add them as repository Secrets.")
            print("Never send the keys to anyone.")
            return 2
        client = BitunixClient(api_key, secret_key)

        print("Checking the key with a read-only account call...")
        account = client.get("/api/v1/futures/account", {"marginCoin": "USDT"})
        print(f"Key works. Account answer received: {json.dumps(account)[:200]}...")

        print("Downloading position history + TPSL...")
        positions, tpsl_all = fetch_window(client, start_ms, end_ms)
        print(f"  {len(positions)} positions, {len(tpsl_all)} TPSL records")

        if args.last_full_week:
            # also fetch the week before, only for the comparison block
            p_start, p_end = start_ms - 7 * 86400 * 1000, start_ms - 1000
            try:
                p_pos, p_tpsl = fetch_window(client, p_start, p_end)
                prev_stats = summarize(rows_from(p_pos, p_tpsl), "prev")
            except Exception as e:  # comparison is nice-to-have, not fatal
                print(f"Previous-week comparison skipped: {e}")

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    (OUTPUT_DIR / f"raw_positions_{label}_{stamp}.json").write_text(
        json.dumps(positions, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUTPUT_DIR / f"raw_tpsl_{label}_{stamp}.json").write_text(
        json.dumps(tpsl_all, ensure_ascii=False, indent=2), encoding="utf-8")

    rows = rows_from(positions, tpsl_all)

    write_csv(OUTPUT_DIR / f"journal_{label}.csv", rows)
    update_master_journal(rows)

    stats = summarize(rows, label)
    weekly_data = {"summary": stats, "trades": rows}
    if positions:
        # helps Muse diagnose field-name differences in future runs
        weekly_data["debug_position_keys"] = sorted(positions[0].keys())
        weekly_data["debug_tpsl_keys"] = (
            sorted(tpsl_all[0].keys()) if tpsl_all else [])
    data_path = OUTPUT_DIR / f"weekly_data_{label}.json"
    data_path.write_text(
        json.dumps(weekly_data, ensure_ascii=False, indent=2), encoding="utf-8")

    report_text = build_report_text(rows, stats, prev_stats)
    report_path = OUTPUT_DIR / f"weekly_report_{label}.txt"
    report_path.write_text(report_text, encoding="utf-8")
    summary_txt = report_text

    if args.notion:
        notion_sync(rows, cfg)

    if args.telegram:
        token = cfg.get("TELEGRAM_BOT_TOKEN", "")
        chat_id = cfg.get("TELEGRAM_CHAT_ID", "")
        if not token or not chat_id or "PASTE" in token:
            print("\nERROR: --telegram needs TELEGRAM_BOT_TOKEN and "
                  "TELEGRAM_CHAT_ID (in .env locally, or GitHub Secrets).")
            return 3
        print("Sending the report to Telegram...")
        telegram_send_message(token, chat_id, report_text)
        telegram_send_document(token, chat_id, data_path,
                               caption="weekly_data (for Muse deep reports)")
        telegram_send_document(token, chat_id,
                               OUTPUT_DIR / f"journal_{label}.csv",
                               caption="Weekly journal CSV")
        print("Telegram: report + files sent.")

    STATE_FILE.write_text(json.dumps(
        {"last_run": datetime.now().isoformat(), "last_window": label,
         "last_trades": len(rows)}, indent=2), encoding="utf-8")

    print("\nDone.")
    print(summary_txt)
    print(f"Files are in: {OUTPUT_DIR}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
